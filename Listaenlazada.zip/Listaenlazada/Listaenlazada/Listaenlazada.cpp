#include <iostream>
#include <string>
using namespace std;

class Node {
public:
    string clientes;
    string productos;
    int cantidades;
    int precios;
    int importe;

    Node* next;
};

class LinkedList {
private:
    Node* first;
public:
    LinkedList() {
        first = nullptr;
    }
    LinkedList(string clientes[], string productos[], int cantidades[], int precios[], int n);
    void display();
    int length();
    void mayor();
    void menor();
    void insert(string clientes, int index, int semestre, string carreara, int valor);
    int deleteNode(int index);
    int aprobados();
    int reprobados();
    int promedio();


};

LinkedList::LinkedList(string clientes[], string productos[], int cantidades[], int precios[], int n) {
    Node* t, * last;
    first = new Node();
    first->clientes = clientes[0];
    first->productos = productos[0];
    first->cantidades = cantidades[0];
    first->precios = precios[0];
    first->importe = precios[0] * cantidades[0];

    first->next = nullptr;
    last = first;

    for (int i = 1; i < n; i++) {
        t = new Node();
        t->clientes = clientes[i];
        t->productos = productos[i];
        t->cantidades = cantidades[i];
        t->precios = precios[i];
        t->importe = precios[i] * cantidades[i];
        last->next = t;
        last = t;
    }
}
void LinkedList::display() {
    Node* p = first;
    int totales_cant = 0;
    int totales_prec = 0;
    while (p) {
        cout << p->clientes << "\t" << p->productos << "\t\t" << p->cantidades << "\t\t" << p->precios << "\t" << p->importe << endl;
        totales_cant += p->cantidades;
        totales_prec += p->importe;
        p = p->next;
    }
    cout << "======================================================" << endl;
    cout << "Totales: \t\t" << totales_cant << "\t\t\t" << totales_prec << endl;
}

int LinkedList::length() {
    Node* p = first;
    int contador = 0;
    while (p) {
        contador = contador + 1;
        p = p->next;
    }
    return contador;
}


void LinkedList::mayor() {
    Node* p = first;
    int maximo = 0;
    string nombre;

    while (p) {
        if (p->importe > maximo) {
            maximo = p->importe;
            nombre = p->clientes;
        }
        p = p->next;
    }
    cout << "Cliente con mayor compra: " << maximo << "\t" << nombre << endl;

}

void LinkedList::menor() {
    Node* p = first;
    int minimo = first->importe;
    string nombre = first->clientes;
    while (p) {
        if (p->importe < minimo) {
            minimo = p->importe;
            nombre = p->clientes;
        }
        p = p->next;
    }
    cout << "Cliente con menor compra: " << minimo << "\t" << nombre << endl;

}

int LinkedList::promedio() {
    Node* p = first;
    int suma = 0;
    int contador = 0;
    int promedio = 0;
    while (p) {
        suma += p->importe;
        contador++;
        p = p->next;
    }
    promedio = suma / contador;

    return promedio;
}
int main() {
    int A[] = { 90,40,80,30 };
    string clientes[] = { "LUIS","PEPE","MARIA","CARLOS" };
    string productos[] = { "CELULAR","TABLET","cELULAR","TABLET" };
    int cantidades[] = { 2,1,4,3 };
    int precios[] = { 7000,8000,7000,8000 };

    int n = sizeof(A) / sizeof(A[0]);
    LinkedList lista(clientes, productos, cantidades, precios, n);

    cout << "======================Lista Enlazada==================" << endl;
    cout << "Nombre\tProducto\tCantidad\tPrecio\tTotal" << endl;
    lista.display();
    lista.mayor();
    lista.menor();
    cout << "El promedio de compras es: " << lista.promedio() << endl;
    //cout << "El tamanio de la lista es: " << lista.length() << endl;


    return 0;

}