#include <iostream>
using namespace std;

int fibonacci(int n) {
    if (n <= 0)            // caso base 1
        return 0;
    if (n == 1)            // caso base 2
        return 1;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

int main() {
    int terms;
    cout << "¿Cuántos términos de Fibonacci quieres ver? ";
    cin >> terms;

    cout << "Serie Fibonacci: ";
    for (int i = 0; i < terms; i++) {
        cout << fibonacci(i) << " ";
    }
    cout << endl;
    return 0;
}