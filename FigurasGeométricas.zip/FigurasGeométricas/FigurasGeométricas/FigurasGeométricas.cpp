#include <iostream>
using namespace std;

const double PI = 3.141592653589793;

// Funciones para calcular áreas
double areaTriangulo(double base, double altura) {
    return (base * altura) / 2.0;
}

double areaCuadrado(double lado) {
    return lado * lado;
}

double areaCirculo(double radio) {
    return PI * radio * radio;
}

int main() {
    int opcion;
    do {
        // Menú
        cout << "\n===== Cálculo de Áreas =====\n";
        cout << "1. Triángulo\n";
        cout << "2. Cuadrado\n";
        cout << "3. Círculo\n";
        cout << "0. Salir\n";
        cout << "Elige una opción: ";
        cin >> opcion;

        switch (opcion) {
        case 1: {
            double base, altura;
            cout << "Ingresa la base del triángulo: ";
            cin >> base;
            cout << "Ingresa la altura del triángulo: ";
            cin >> altura;
            cout << "Área del triángulo: "
                << areaTriangulo(base, altura)
                << "\n";
            break;
        }
        case 2: {
            double lado;
            cout << "Ingresa el lado del cuadrado: ";
            cin >> lado;
            cout << "Área del cuadrado: "
                << areaCuadrado(lado)
                << "\n";
            break;
        }
        case 3: {
            double radio;
            cout << "Ingresa el radio del círculo: ";
            cin >> radio;
            cout << "Área del círculo: "
                << areaCirculo(radio)
                << "\n";
            break;
        }
        case 0:
            cout << "Saliendo...\n";
            break;
        default:
            cout << "Opción no válida. Intenta de nuevo.\n";
        }
    } while (opcion != 0);

    return 0;
}