#include <iostream>
using namespace std;

#define STACK_SIZE 256
typedef char arreglo[STACK_SIZE];

class stack {
private:
    int sp;       
    int items;    
    arreglo pila;

public:
    // constructor
    stack() {
        sp = STACK_SIZE - 1;
        items = 0;
    }

    // destructor
    ~stack() {}

    int size() const {
        return items;
    }

    bool empty() const {
        return items == 0;
    }

    bool full() const {
        return items == STACK_SIZE;
    }

    void put(char d) {
        if (!full()) {
            pila[sp] = d;
            sp--;
            items++;
        }
        else {
            cout << "Error: pila llena\n";
        }
    }

    char get() {
        if (!empty()) {
            sp++;
            items--;
            return pila[sp];
        }
        else {
            cout << "Error: pila vacia\n";
            return '\0';
        }
    }
};

int main() {
    stack s;  

    
    for (char d = 'A'; d <= 'Z'; d++) {
        s.put(d);
    }

    cout << "Items = " << s.size() << endl;

    
    while (!s.empty()) {
        cout << s.get() << " ";
    }

    cout << "\nPara terminar, oprima <Enter>...";
    cin.get(); 
    return 0;
}