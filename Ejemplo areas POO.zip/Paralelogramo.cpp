#include "Paralelogramo.h"
Paralelogramo::Paralelogramo() {
}
void Paralelogramo::set_basePa(float _base) {
	basePa = _base;
}
void Paralelogramo::set_alturaPa(float _altura) {
	alturaPa = _altura;
}
float Paralelogramo::get_basePa() {
	return basePa;
}
float Paralelogramo::get_alturaPa() {
	return alturaPa;
}
double Paralelogramo::areaPa() {
	return (basePa * alturaPa);
}
