#pragma once
class Circulo {
private:
	float radioCirculo; //Creamos el atributo
public:
	Circulo();
	void set_radioC(float _radioCirculo); //Definimos el setter 
	float get_radioC(); //Definimos la funcion que envia el radio al main
	double AreaCirculo(); //Funcion que calculo el area del circulo

};

