#pragma once
class Cuadrado {
private:
    float ladoCuadrado;
public:
    Cuadrado();
    float get_ladoCuadrado();
    void set_ladoCuadrado(float _ladoCuadrado);
    double AreaCuadrado();
};


