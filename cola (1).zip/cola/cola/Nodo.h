#pragma once
#include <string>

using namespace std;

class Nodo
{
   public: 
   // Atributos
	int numero;
	string Cliente;
	
	// M�todos
	// Al tener dos constructores es polimorfismo
	Nodo();
	Nodo(int _numero, string _cliente);
};

