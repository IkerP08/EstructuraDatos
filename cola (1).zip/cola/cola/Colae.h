#pragma once
#include "Nodo.h"
#define MAX 100
// Declarar la estructura de una cola de enteros
class Colae
{ private: 
	Nodo info[MAX]; // Esto reemplaza al nodo
	int ini, fin;
 public: 
	Colae (void); 
	bool Encolar (Nodo Valor); // (int Valor, string descrip)
	bool Desencolar (void); 
	bool PrimeroCola (Nodo &Valor); 
	bool ColaVacia (void);
	void mostrar (void);
};


