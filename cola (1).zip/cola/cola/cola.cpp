#include "stdafx.h" // Libreria por compilar en Visual C v10
#include "conio.h" // getch()
#include <iostream>
#include "Colae.h" //No se olviden declarar la clase
#include "Nodo.h"
#include <string>

#define MAX 100 // MAX es una constante de compilador

using namespace std;

void main()
{
	Colae cola; // Se crea el objeto "cola"
	Nodo Valor;
	for (int j = 1; j < 10; j++) 
	{
		Valor.numero = j;
		cout << " Ingresa el nombre del cliente ";
		if (!cola.Encolar(j))
			cola.mostrar();
		else
			cout << "Error";
	}
	cout << endl << "Desencolar" << endl;
	if (!cola.Desencolar())
		cola.mostrar();
	else
		cout << "Error";
	if (!cola.PrimeroCola(Valor))
		cout<<"Valor: "<<Valor;
	getch();
}