#include <iostream>
#include "Empleados.h"
#include "Planilla.h"

using namespace std;

int main()
{
    //MENÚ

    int n;
    do {
        cout << "Ingresar el número de empleados" << endl;
        cin >> n;
    } while ((n < 1) || (n > MAX));

}