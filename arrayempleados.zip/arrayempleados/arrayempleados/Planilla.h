#pragma once
#include "Empleados.h"
#define MAX 10;
class Planilla
{
private:
	Empleado planilla[MAX];
public:
	Planilla();
	//pida los datos de los empleados
	void mostrarplanilla(int n);
};

