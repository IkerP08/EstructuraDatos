#include "Empleados.h"
#include <iostream>
Empleado::Empleado() {

}
int Empleado::getcodigo() {
	return codigo;
}
void Empleado::setcodigo(int codigo) {
	codigo = _codigo;
}
string Empleado::getnombre() {
	return nombre;
}
void Empleado::setnombre(string nombre) {
	nombre = _nombre;
}
string Empleado::getapellido() {
	return apellido;
}
void Empleado::setapellido(string apellido) {
	apellido = _apellido;
}
string Empleado::getafecnac() {
	return fecnac;
}
void Empleado::setfecnac(string fecnac) {
	fecnac = _fecnac;
}
string Empleado:: getdireccion() {
	return direccion;
}
void Empleado::setdireccion(string direccion) {
	direccion = _direccion;
}
string Empleado::gettelefono() {
	return telefono;
}
void Empleado::settelefono(string telefono) {
	telefono = _telefono;
}
float Empleado::getsb() {
	return sb;
}
void Empleado::setsb(float sb) {
	sb = _sb;
}
void Empleado::setEmpleado() {
	cout << "Ingresar el nombre del empleado" << endl;
	cin >> nombre;
}