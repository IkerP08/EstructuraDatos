#pragma once
#include <iostream>
#include <string>

using namespace std;

class Empleado
{
private:
	int codigo;
	string nombre;
	string apellido;
	string fecnac;
	string direccion;
	string telefono;
	float sb;
public:
	Empleado();
	int getcodigo();
	void setcodigo(int _codigo);
	string getnombre();
	void setnombre(string _nombre);
	string getapellido();
	void setapellido(string _apellido);
	string getafecnac();
	void setfecnac(string _fecnac);
	string getdireccion();
	void setdireccion(string _direccion);
	string gettelefono();
	void settelefono(string _telefono);
	float getsb();
	void setsb(float _sb);

	//metodo para ingresar datos del empleado
};

