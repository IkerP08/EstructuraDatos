#include <iostream>
#include <cstring>
using namespace std;

#define MAX_SIZE 256
#define T_ERROR (-1)

typedef int DATA_TYPE;
typedef DATA_TYPE almacen[MAX_SIZE];

class SDQueue {
    int itemsize;
    int items;
    int cola;
    int cabeza;
    almacen alma;

public:
    SDQueue()
        : itemsize(sizeof(DATA_TYPE)), items(0),
        cola(0), cabeza(0) {
    }
    ~SDQueue() {}

    bool empty() const { return items == 0; }
    int size() const { return items; }

    DATA_TYPE put_back(DATA_TYPE valor) {
        if (items == MAX_SIZE) return T_ERROR;
        alma[cola++] = valor;
        items++;
        return valor;
    }

    DATA_TYPE put_front(DATA_TYPE valor) {
        if (items == MAX_SIZE) return T_ERROR;
        memmove(&alma[cabeza + 1],
            &alma[cabeza],
            items * itemsize);
        alma[cabeza] = valor;
        items++;
        cola++;
        return valor;
    }

    DATA_TYPE get_front() {
        if (empty()) return T_ERROR;
        DATA_TYPE d = alma[cabeza];
        items--;
        cola--;
        memmove(&alma[cabeza],
            &alma[cabeza + 1],
            items * itemsize);
        return d;
    }

    DATA_TYPE get_back() {
        if (empty()) return T_ERROR;
        cola--;
        items--;
        return alma[cola];
    }
};

int main() {
    SDQueue s;
    DATA_TYPE d;

    for (d = 'A'; d <= 'Z'; d++) {
        s.put_back(d);
    }

    while (!s.empty()) {
        cout << static_cast<char>(s.get_front()) << " ";
    }

    cout << "\nPara terminar presione <Enter>...";
    cin.get();
    return 0;
}