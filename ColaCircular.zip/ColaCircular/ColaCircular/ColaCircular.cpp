#include <iostream>
#include <string>
using namespace std;

struct Nodo {
    string valor;
    Nodo* sig;
    Nodo(const string& v) : valor(v), sig(nullptr) {}
};

class ColaCircular {
private:
    Nodo* frente;
    Nodo* final;

public:
    ColaCircular() : frente(nullptr), final(nullptr) {}
    ~ColaCircular() {
        while (!estaVacia()) {
            desencolar();
        }
    }

    void encolar(const string& valor) {
        Nodo* nuevo = new Nodo(valor);
        if (!frente) {
            frente = final = nuevo;
            nuevo->sig = nuevo;
        }
        else {
            nuevo->sig = frente;
            final->sig = nuevo;
            final = nuevo;
        }
    }

    string desencolar() {
        if (estaVacia()) return {};
        string dato;
        if (frente == final) {
            dato = frente->valor;
            delete frente;
            frente = final = nullptr;
        }
        else {
            Nodo* temp = frente;
            dato = temp->valor;
            frente = frente->sig;
            final->sig = frente;
            delete temp;
        }
        return dato;
    }

    bool estaVacia() const {
        return frente == nullptr;
    }

    void mostrar() const {
        if (estaVacia()) {
            cout << "Cola vacía.\n";
            return;
        }
        Nodo* actual = frente;
        cout << "Cola: ";
        do {
            cout << "[" << actual->valor << "] ";
            actual = actual->sig;
        } while (actual != frente);
        cout << "\n";
    }
};

int main() {
    ColaCircular cola;
    cola.encolar("Juan");
    cola.encolar("Maria");
    cola.encolar("Pedro");
    cola.mostrar();

    cout << "Atendiendo: " << cola.desencolar() << "\n";
    cola.mostrar();

    cola.encolar("Luis");
    cola.mostrar();

    cout << "Atendiendo: " << cola.desencolar() << "\n";
    cout << "Atendiendo: " << cola.desencolar() << "\n";
    cola.mostrar();

    return 0;
}