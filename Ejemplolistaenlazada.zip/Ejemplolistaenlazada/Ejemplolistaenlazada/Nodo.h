#pragma once

using namespace std;

class Nodo
{
private:
	Dato dato;
	Nodo* puntero;
public:
	Nodo();//Constructor
	Nodo(Dato d);
	//Getters y setters
	Nodo* getPuntero() const;
	void setPuntero(Nodo* p);
	Dato getDato() const;
	void setDato(const Dato& d);

	//Especificos
	static void Encolar(Nodo*& inicio, Nodo*& fin);
	static void Desencolar(Nodo*& inicio);
	//Funcion para encontrar un nodo por su c�digo
	Nodo* BuscarElemento(Nodo* inicio, double codigo);

	//Funcion para eliminar un nodo por su c�digo
	void EliminarElemento(Nodo*& inicio, double codigo);
};

