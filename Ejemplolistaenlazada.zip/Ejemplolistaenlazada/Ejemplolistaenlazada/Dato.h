#pragma once
#include <string>

using namespace std;

class Dato
{
private:
	double Codigo;
	string Nombre;
	string Carrera;
public:
	Dato();
	double getCodigo() const;
	void setCodigo(double codigo);
	string getNombre() const;
	void setNombre(const string& nombre);
	string getCarrera() const;
	void setCarrera(const string& carrera);
};

