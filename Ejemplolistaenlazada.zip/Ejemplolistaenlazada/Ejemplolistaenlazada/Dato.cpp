#include "Dato.h"
#include <iostream>
#include <string>

using namespace std;

double Dato::getCodigo() const {
	return Codigo;
}
void Dato::setCodigo(double codigo) {
	Codigo = codigo;
}
string Dato::getNombre() const {
	return Nombre
}
void Dato::setNombre(const string& nombre) {
	Nombre = nombre;
}
string Dato::getCarrera() const {
	return Carrera;
}
void Dato::setCarrera(const string& carrera) {
	Carrera = carrera;
}