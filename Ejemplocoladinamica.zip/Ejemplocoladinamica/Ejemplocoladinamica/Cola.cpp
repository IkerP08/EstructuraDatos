#include "Cola.h"

Cola::Cola() //Constructor
{

}
void Cola::Encolar(Dato elemento)
{

}
void Cola::Desencolar()
{

}
bool Cola::Vacio()
{
}
bool Cola::Lleno()
{

}
void Cola::MostrarDatos() {

}
