#include "Nodo.h"
Nodo::Nodo(Dato dato)
{
        sig = NULL;
}
