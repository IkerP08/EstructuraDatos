#include "Dato.h"
Dato::Dato()
{
	placa="";
	modelo="";
	marca="";
	color="";
}