#pragma once
#include <string>

using namespace std;

class Dato
{
public:
	// Clase para autos
	string placa;
	string modelo;
	string marca;
	string color;
public:
	Dato();
};

