#include <iostream>
using namespace std;

#define MAX 10

class Fila {
private:
    float elementos[MAX];

public:
    void set(int i, float valor) {
        elementos[i] = valor;
    }

    float get(int i) const {
        return elementos[i];
    }

    void mostrar(int n) const {
        for (int i = 0; i < n; i++) {
            cout << elementos[i] << "\t";
        }
        cout << endl;
    }
};

class Matriz {
private:
    Fila filas[MAX];
    int totalFilas;
    int columnas;

public:
    Matriz(int totalFilas_, int columnas_) {
        totalFilas = totalFilas_;
        columnas = columnas_;
    }

    void setDato(int i, int j, float valor) {
        filas[i].set(j, valor);
    }

    float getDato(int i, int j) const {
        return filas[i].get(j);
    }

    void mostrar() const {
        for (int i = 0; i < totalFilas; i++) {
            filas[i].mostrar(columnas);
        }
    }
};

void procesarDatos(Fila entrada[], int n, Matriz& salida) {
    int filaSalida = 0;
    for (int i = 0; i < n; i++) {       
        for (int j = 0; j < n; j++) {   
            float valor = entrada[i].get(j);
            for (int k = 0; k < n; k++) {
                salida.setDato(filaSalida, k, valor);
            }
            filaSalida++;
        }
    }
}

int main() {
    const int n = 3;
    Fila entrada[MAX];

    cout << "Ingrese los datos de una matriz " << n << "x" << n << " (valores reales):" << endl;

    for (int i = 0; i < n; i++) {
        cout << "Fila " << i + 1 << ":" << endl;
        for (int j = 0; j < n; j++) {
            float valor;
            cout << "  Valor[" << i << "][" << j << "]: ";
            cin >> valor;
            entrada[i].set(j, valor);
        }
    }

    Matriz salida(n * n, n);

    procesarDatos(entrada, n, salida);

    cout << "\nMatriz Generada:" << endl;
    salida.mostrar();

    return 0;
}