// FuncionRecursiva.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
using namespace std;

int factorial(int n) {
    if (n <= 1)            // caso base: 0! = 1! = 1
        return 1;
    return n * factorial(n - 1);
}

int main() {
    int num;
    cout << "Ingresa un número para calcular su factorial: ";
    cin >> num;

    cout << "Factorial de " << num << " es " << factorial(num) << endl;
    return 0;
}